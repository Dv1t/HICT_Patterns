import entrypoint

def main():
    entrypoint.main()


if __name__ == '__main__':
    main()